// Character Sheet
/* globals ActorSheet, game, foundry */

import { AttributeRollDialog, StatCheckDialog } from "./roll-dialog.js";

export class ElementaCharacterSheet extends ActorSheet {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      width: 800,
      height: 760,
    });
  }

  get template() {
    return "/systems/fvtt-elemental/templates/character.hbs";
  }

  async getData(options) {
    const data = super.getData(options);
    return { ...data, theme: game.elemental.current_theme };
  }

  activateListeners(jquery) {
    super.activateListeners(jquery);
    jquery.find(".elemental-tab-control").on("click", (ev) => {
      this.manageTabs(ev, jquery);
    });
    jquery.find(".elemental-refresh-derived").on("click", (ev) => {
      this.refresh_derived(ev);
    });
    jquery.find(".elemental-delete-skill").on("click", (ev) => {
      this.delete_item(ev);
    });
    jquery.find(".elemental-edit-skill").on("click", (ev) => {
      this.edit_item(ev);
    });
    jquery.find(".elemental-roll-derived").on("click", (ev) => {
      const derived_stat = ev.currentTarget.dataset.derived;
      const stat_roll_dialog = new StatCheckDialog(this.actor, derived_stat);
      stat_roll_dialog.render(true);
    });
    jquery.find(".elemental-roll-attribute").on("click", (ev) => {
      const attribute = ev.currentTarget.dataset.attribute;
      const attribute_roll_dialog = new AttributeRollDialog(
        this.actor,
        attribute,
      );
      attribute_roll_dialog.render(true);
    });
  }

  manageTabs(ev, jquery) {
    const { current_theme } = game.elemental;
    let visible_content_id = "";
    for (let tab of jquery.find(".elemental-tab-control")) {
      if (tab === ev.currentTarget) {
        tab.classList =
          `elemental-tab-control ${current_theme.tab_active}`.split();
        visible_content_id = tab.dataset.tab;
      } else {
        tab.classList =
          `elemental-tab-control ${current_theme.tab_inactive}`.split();
      }
    }
    jquery.find(".tab-content").addClass("hidden");
    jquery.find(`#${visible_content_id}`).removeClass("hidden");
  }

  refresh_derived(ev) {
    const actor_property = `max_${ev.currentTarget.dataset.derived}`;
    ev.currentTarget.nextElementSibling.value = this.actor[actor_property];
  }

  delete_item(ev) {
    const item_id = ev.currentTarget.dataset.itemId;
    const item = this.actor.items.get(item_id);
    item.delete();
  }

  edit_item(ev) {
    const item_id = ev.currentTarget.dataset.itemId;
    const item = this.actor.items.get(item_id);
    item.sheet.render(true);
  }

  async _updateObject(event, formData) {
    if (
      event.currentTarget &&
      event.currentTarget.classList.contains("elemental-skill-value")
    ) {
      await this.update_skill_value(
        event.currentTarget.name,
        event.currentTarget.value,
      );
    }
    return super._updateObject(event, formData);
  }

  async update_skill_value(skill_id, skill_value) {
    let real_value = parseInt(skill_value);
    real_value = Math.max(real_value, 1);
    real_value = Math.min(real_value, 3);
    const skill = this.actor.items.get(skill_id, { strict: true });
    await skill.update({ "system.score": real_value });
  }
}
